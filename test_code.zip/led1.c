#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define LIGHT_OFF 0
#define LIGHT_ON 1
int main()
{

    int fd = open("/dev/leds", O_RDWR);
    if (-1 == fd)
        exit(-1);

    ioctl(fd, LIGHT_OFF, 0);
    ioctl(fd, LIGHT_OFF, 1);

    while (1)
    {
        ioctl(fd, LIGHT_ON, 0);
        ioctl(fd, LIGHT_ON, 1);
        sleep(1);
        ioctl(fd, LIGHT_OFF, 0);
        ioctl(fd, LIGHT_OFF, 1);
        sleep(1);
    }
    return 0;
}