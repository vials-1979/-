ifconfig eth0 192.168.122.2

mount -t nfs -o nolock 192.168.122.3:/home/vials/test_code /mnt