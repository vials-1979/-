#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>


int uart_fd,nByte;
char *uart1 = "/dev/ttySAC1";
char buffer[512];

int set_opt(int,int,int,char,int);
//"/dev/ttySAC3"是con2，靠近耳机接口的串口
void config_wifi()
{
    char *cipmode="AT+CIPMODE=1\r\n";
    char *cipstart="AT+CIPSTART=\"UDP\",\"192.168.4.2\",9000,9000,0\r\n";
    char *cipsend="AT+CIPSEND\r\n";

    write(uart_fd,cipmode,strlen(cipmode));	
	sleep(1);
	write(uart_fd,cipstart,strlen(cipstart));
	sleep(1);
	write(uart_fd,cipsend,strlen(cipsend));
	sleep(1);
	
}

void main()
{
	
	
    printf("Ready to Init Uart1!");
	if((uart_fd = open(uart1, O_RDWR|O_NOCTTY))<0)
		printf("open %s is failed!",uart1);
	else{
                printf("open %s is successfully!",uart1);
		        set_opt(uart_fd, 115200, 8, 'N', 1);
	    }			
		//config wifi
		config_wifi();
		
		while(1){
			while((nByte = read(uart_fd, buffer, 512))>0){
				buffer[nByte+1] = '\0';	
                //process command
				if(buffer[0]=='C' && buffer[8]=='1')
				{
					printf("Receive Command01!\n");
					
				}
				
				if(buffer[0]=='C' && buffer[8]=='2')
				{
					printf("Receive Command02!\n");
					
				}
				
				if(buffer[0]=='C' && buffer[8]=='3')
				{
					printf("Receive Command03!\n");
					
				}
				
				if(buffer[0]=='C' && buffer[8]=='4')
				{
					printf("Receive Command04!\n");
					
				}
				//write(fd,buffer,strlen(buffer));
				//memset(buffer, 0, strlen(buffer));
				nByte = 0;
			}
		}
	}
}

int set_opt(int fd,int nSpeed, int nBits, char nEvent, int nStop)
{
	struct termios newtio,oldtio;
	if  ( tcgetattr( fd,&oldtio)  !=  0) { 
		perror("SetupSerial 1");
		return -1;
	}
	bzero( &newtio, sizeof( newtio ) );
	newtio.c_cflag  |=  CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	switch( nBits )
	{
		case 7:
			newtio.c_cflag |= CS7;
			break;
		case 8:
			newtio.c_cflag |= CS8;
			break;
	}

	switch( nEvent )
	{
	case 'O':
		newtio.c_cflag |= PARENB;
		newtio.c_cflag |= PARODD;
		newtio.c_iflag |= (INPCK | ISTRIP);
		break;
	case 'E': 
		newtio.c_iflag |= (INPCK | ISTRIP);
		newtio.c_cflag |= PARENB;
		newtio.c_cflag &= ~PARODD;
		break;
	case 'N':  
		newtio.c_cflag &= ~PARENB;
		break;
	}

	switch( nSpeed )
	{
		case 2400:
			cfsetispeed(&newtio, B2400);
			cfsetospeed(&newtio, B2400);
			break;
		case 4800:
			cfsetispeed(&newtio, B4800);
			cfsetospeed(&newtio, B4800);
			break;
		case 9600:
			cfsetispeed(&newtio, B9600);
			cfsetospeed(&newtio, B9600);
			break;
		case 115200:
			cfsetispeed(&newtio, B115200);
			cfsetospeed(&newtio, B115200);
			break;
		case 460800:
			cfsetispeed(&newtio, B460800);
			cfsetospeed(&newtio, B460800);
			break;
		default:
			cfsetispeed(&newtio, B9600);
			cfsetospeed(&newtio, B9600);
			break;
	}
	if( nStop == 1 )
		newtio.c_cflag &=  ~CSTOPB;
	else if ( nStop == 2 )
		newtio.c_cflag |=  CSTOPB;
		newtio.c_cc[VTIME]  = 0;
		newtio.c_cc[VMIN] = 0;
		tcflush(fd,TCIFLUSH);
	if((tcsetattr(fd,TCSANOW,&newtio))!=0)
	{
		perror("com set error");
		return -1;
	}
	
	//	printf("set done!\n\r");
	return 0;
}


