#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>
#include<linux/fb.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/mman.h>

int framebuffer_fd=0;
int fb=0;
unsigned int x,y,i;
struct fb_var_screeninfo vinfo;
struct fb_fix_screeninfo finfo;
long int screensize=0;
char *fbp=0;

unsigned char str[]="按";//
unsigned char str1[]="神";

struct stat hzk_stat;
unsigned char *hzkmem;
int hzk_fd;
unsigned int line_width;
unsigned int pixel_width; 

void lcd_put_pixel( int x, int y, unsigned int color );
void lcd_put_chinese( int x, int y, unsigned char *c,unsigned int frontcolor,unsigned int backcolor);

int main(int argc, char** argv){

    framebuffer_fd = open("/dev/fb0",O_RDWR);
	if(framebuffer_fd<=0)
	{
		printf("error:can not open framebuffer device.\n");
		return -1;
	}
	printf("the framebuffer device was opened successfully.\n");


	if(ioctl(framebuffer_fd, FBIOGET_VSCREENINFO, &vinfo))//��ȡFrameBuffer�豸�Ŀɱ������Ϣ��
	{
		printf("error reading variable information.\n");
		return -3;
	}


	if (ioctl(framebuffer_fd, FBIOGET_FSCREENINFO, &finfo))//��ʾ��ȡFrameBuffer�豸�Ĺ̶�������Ϣ����Ȼ�ǹ̶��������Ǿ���ζ��Ӧ�ó��򲻿��޸ġ�
	{
		printf("Error reading fixed information.\n");
		exit(-3);
	}

	line_width = vinfo.xres * vinfo.bits_per_pixel / 8;
	pixel_width = vinfo.bits_per_pixel / 8;
	screensize = vinfo.xres*vinfo.yres*vinfo.bits_per_pixel/8;

	fbp=(char*)mmap(0, screensize,PROT_READ|PROT_WRITE,MAP_SHARED,framebuffer_fd,0);
    // fbp=(char*)mmap(NULL, screensize,PROT_READ|PROT_WRITE,MAP_SHARED,framebuffer_fd,0);
	if((int)fbp==-1)
	{
		printf("error:failed to map framebuffer device to memory.\n");
		return -4;
	}
	printf("success to map framebuffer device to memory.\n"); 

    hzk_fd = open("HZK16",  O_RDONLY );//ֻ����
		if( hzk_fd<0 )
		{
			printf("can't open hzk\n");
			return -1;
		}

		if( fstat(hzk_fd, &hzk_stat))//��ȡhzk�ļ���״̬�������С������֮���
		{
			printf("can't get fstat\n");
			return -1;
		}

		hzkmem = (unsigned char *)mmap( NULL, hzk_stat.st_size,  PROT_READ, MAP_SHARED,hzk_fd,0 );
		if( hzkmem == (unsigned char *)-1 )
		{
			printf("mmap hzk is failed\n");
			return -1;
		} 
    
    memset(fbp,0,screensize);
    
    lcd_put_chinese(vinfo.xres/2,vinfo.yres/2,str,0x0000ff,0x000000); 



    return 0;
}

//Framebuffer 
void lcd_put_pixel( int x, int y, unsigned int color )
{
    unsigned char *pen_8 = fbp +y*line_width + x*pixel_width;
    unsigned short *pen_16;
    unsigned int *pen_32;
    unsigned char red,green,blue;

    pen_16 = (unsigned short *)pen_8;//2
    pen_32 = (unsigned int *)pen_8;//4

    switch( pixel_width*8 )
    {
    case 8:
        *pen_8 = color;
        break;

    case 16:
        /* 565 */
        red = (color>>16) & 0xff;
        green = (color>>8) & 0xff;
        blue = (color>>0) & 0xff;
        color = ((red>>3)<<11) | ((green>>2)<<5) |((blue>>3));
        *pen_16 = color;
        break;

    case 32:
        *pen_32 = color;
        break;
    default:
        printf("can't support %ddpp\n",pixel_width*8 );
        break;
    }
} 


void lcd_put_chinese( int x, int y, unsigned char *c,unsigned int frontcolor,unsigned int backcolor)
{
    unsigned int area = c[0] - 0xa1;
    unsigned int where = c[1] - 0xa1;

    //以上改动
    unsigned char *dots = hzkmem + (area*94+where)*32;//这里应该是固定死的,基址+偏移得到的字符地址
    unsigned char byte;
    int i,j,b;
    for( i=0; i<16; i++ )
    {
        for( j=0; j<2; j++ )
        {
            byte = dots[i*2+j];//
            for( b=7; b>=0; b-- )
            {
                if( byte & (1<<b) )
                    lcd_put_pixel(x+j*8+7-b,y+i, frontcolor );
                else
                    lcd_put_pixel(x+j*8+7-b,y+i, 0x000000 );
            }
        }
    }
} 
