#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <errno.h>
#include <linux/input.h>

int ts_fd; 
struct input_event ev0[64];//输入事件数组


//event2代表了屏幕输入设备


static int handle_event2()
{
    int realx=0,realy=0,i,rd;
    rd=read(ts_fd,ev0,sizeof(struct input_event)*64);
    if(rd<sizeof(struct input_event)) return 0;
    //对每一个事件进行操作
    for(i=0;i<rd /sizeof(struct input_event);i++)
       {
          if(EV_ABS==ev0[i].type)//描述坐标轴的变化
          {
             if(ev0[i].code==0)
               {
                  realx=ev0[i].value;
               }
             if(ev0[i].code==1)
               {
                  realy=ev0[i].value;
               }

          }
          printf("event(%d):type:%d:code:%3d:value:%3d:realx:%3d:realy:%3d\n",i,
          ev0[i].type,ev0[i].code,ev0[i].value,realx,realy);
       }

        return 1;
}

int main ()  
{  
   
  int done=1; 
  
  ts_fd = open ("/dev/input/event2", O_RDONLY);  
  if (ts_fd <= 0)  
    {  
      printf ("open /dev/input/event2 device error!\n");  
      return 0;  
    } 
  printf ("open /dev/input/event2 device successfully!\n");  
  
  while (done)  
    {  
      printf("begin handel_event2......\n");
      done=handle_event2();
      printf("end handel_event0......\n");
    }  
  close (ts_fd);  
  
  return 0;  
}  
