#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/mman.h>//mmap的头文件

unsigned int mem_fd,opt;
unsigned int base_addr,led_base_addr,beep_base_addr;
unsigned char *virt_addr;
unsigned int *gpl2con,*gpl2dat,*gpl2pud;
unsigned int *gpk1con,*gpk1dat,*gpk1pud;
unsigned int *gpd0con,*gpd0dat,*gpd0pud;

void gpl2_init(void);
void gpk1_init(void);
void gpd0_init(void);
void mmap_function();

int main(int argc,char **argv)
{
	led_base_addr = 0x11000000;//0x11 00 0000
    beep_base_addr = 0x11400000;//0x11 40 0000

	if(argc != 2) {//输入参数决定led亮还是蜂鸣器叫
        printf("enter num error!\n");
        exit(-1);
	}

    opt = atoi(argv[1]);
    if(opt < 1 || opt > 3) {           //参数范围1-3 
        printf("enter value error!\n");
        exit(-1);
	}

	mem_fd = open("/dev/mem",O_RDWR|O_SYNC);//同步读写打开内存设备
    if(mem_fd == -1) {
		printf("/dev/mem open failed!\n");
		exit(-1);
	}

	switch(opt) {//设备基址初始化
        case 1:
            base_addr = led_base_addr;
            mmap_function();
            gpl2_init();
            break;
        case 2:
            base_addr = led_base_addr;
            mmap_function();
            gpk1_init();
            break;
        case 3:
            base_addr = beep_base_addr;
            mmap_function();
            gpd0_init();
            break;
    }
	
	//unsigned int temp;
	while(1){	

        switch(opt) {
            case 1:
                *gpl2dat |= 0x01;
		        sleep(1);
		        *gpl2dat &= ~(0x01);
		        sleep(1);
                break;
            case 2:
                *gpk1dat |= (0x01 << 1);
		        sleep(1);
		        *gpk1dat &= ~(0x01 << 1);
		        sleep(1);
                break;
            case 3:
                *gpd0dat |= 0x1;
		        sleep(1);
		        *gpd0dat &= ~(0x1);
		        sleep(1);
                break;
        }
		
	}

	return 0;
}

void mmap_function(void)
{
    virt_addr = (unsigned char *)mmap(NULL,0Xff,PROT_READ|PROT_WRITE,MAP_SHARED,mem_fd,base_addr);
    //void *mmap (void *addr, size_t length, int prot, int flags, int fd, off_t offset);
    //MAP_SHARED对映射区域的写入数据会复制回文件内，而且允许其他映射该文件的进程共享。
	if(virt_addr == MAP_FAILED) {
		printf("mmap failed!\n");
		exit(-1);
	}
	else
		printf("mmap success!\n");
}

void gpl2_init(void) 
{
    gpl2con = (unsigned int *)(virt_addr + 0x0100);//0x 01 00 基址+偏移得到io的地址0x11 00 0000+0x01 00==0x 1100 0100
    *gpl2con |= 0x00000001;//0x 00 00 0001 //按位或等：1100 0101

	gpl2dat = (unsigned int *)(virt_addr + 0x0104);//0x01 04    ==1100 0104
    *gpl2dat &= ~(0x01);//按位取反再与等  ：1111 1110&1100 0104

	gpl2pud = (unsigned int *)(virt_addr + 0x0108);
    *gpl2pud |= 0x0003;
}

void gpk1_init(void)
{
    gpk1con = (unsigned int *)(virt_addr + 0x0060);//0x 0060
    *gpk1con |= (0x0000001 << 1);

	gpk1dat = (unsigned int *)(virt_addr + 0x0064);
    *gpk1dat &= ~(0x01 << 1);

	gpk1pud = (unsigned int *)(virt_addr + 0x0068);
    *gpk1pud |= 0x0003;
}

void gpd0_init(void)
{
    gpd0con = (unsigned int *)(virt_addr + 0x00A0);//0x 00A0
    *gpd0con |= (0x0001);//0x 0001 //设置灯的亮灭模式

	gpd0dat = (unsigned int *)(virt_addr + 0x00A4);
    *gpd0dat&=0x0;

	gpd0pud = (unsigned int *)(virt_addr + 0x00A8);
    *gpd0pud |= 0x03;
}