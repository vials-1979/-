#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <termios.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include "show_font.h"
#include <errno.h>

int set_opt(int, int, int, char, int);
//"/dev/ttySAC3"是con2，靠近耳机接口的串口
void config_wifi(int uart_fd);
void lcd_put_pixel(int x, int y, unsigned int color);
void lcd_put_ascii(int x, int y, unsigned char c, unsigned int frontcolor, unsigned int backcolor);
void show_char(int value, int num, char str0[], char str1[]);

struct fb_var_screeninfo vinfo;
struct fb_fix_screeninfo finfo;
long int screensize = 0;
unsigned int line_width;
unsigned int pixel_width;
char *fbp = 0;

int main()
{
	int uart_fd, nByte;
	char *uart1 = "/dev/ttySAC1";
	char buffer[512];
	char *uart_out = "please input\r\n";
	memset(buffer, 0, sizeof(buffer));
	printf("Ready to Init Uart1!\r\n");

	int framebuffer_fd = open("/dev/fb0", O_RDWR);
	if (framebuffer_fd == -1)
	{
		printf("error:can not open framebuffer device.\n");
		return -1;
	}
	printf("the framebuffer device was opened successfully.\n");

	if (ioctl(framebuffer_fd, FBIOGET_VSCREENINFO, &vinfo))
	{
		printf("error reading variable information.\n");
		return -3;
	}

	if (ioctl(framebuffer_fd, FBIOGET_FSCREENINFO, &finfo))
	{
		printf("Error reading fixed information.\n");
		return -4;
	}
	printf("success to map framebuffer device to memory.\n");

	line_width = vinfo.xres * vinfo.bits_per_pixel / 8;
	pixel_width = vinfo.bits_per_pixel / 8;
	screensize = vinfo.xres * vinfo.yres * vinfo.bits_per_pixel / 8;

	fbp = (char *)mmap(0, screensize, PROT_READ | PROT_WRITE, MAP_SHARED, framebuffer_fd, 0);
	if ((int)fbp == -1)
	{
		printf("error:failed to map framebuffer device to memory.\n");
		return -4;
	}

	memset(fbp, 0, screensize);

	/*******/
	int led_fd = open("/dev/leds", O_RDWR);
	if (led_fd == -1)
		printf("open /dev/leds failed!\r\n");

	if ((uart_fd = open(uart1, O_RDWR | O_NOCTTY)) == -1)//实际上是一个串口，通过wifi模块接收串口指令
		printf("open %s is failed!\r\n", uart1);
	else
	{
		printf("open %s is successfully!\r\n", uart1);
		set_opt(uart_fd, 115200, 8, 'N', 1);

		// WIFI config
		config_wifi(uart_fd);
		show_char(0, 0, "LED1", "LED2");
		show_char(0, 1, "LED1", "LED2");

		write(uart_fd, uart_out, strlen(uart_out));
		while (1)
		{
			while ((nByte = read(uart_fd, buffer, 512)) > 0)
			{
				if (buffer[0] == 'C' && buffer[8] == '1')
				{
					ioctl(led_fd, 1, 0);
					show_char(1, 0, "LED1", "LED2");
				}
				if (buffer[0] == 'C' && buffer[8] == '2')
				{
					ioctl(led_fd, 0, 0);
					show_char(0, 0, "LED1", "LED2");
				}
				if (buffer[0] == 'C' && buffer[8] == '3')
				{
					ioctl(led_fd, 1, 1);
					show_char(1, 1, "LED1", "LED2");
				}
				if (buffer[0] == 'C' && buffer[8] == '4')
				{
					ioctl(led_fd, 0, 1);
					show_char(0, 1, "LED1", "LED2");
				}
			}
		}
	}

	return 0;
}

void config_wifi(int uart_fd)
{
	char *cipmode = "AT+CIPMODE=1\r\n";
	char *cipstart = "AT+CIPSTART=\"UDP\",\"192.168.4.2\",9000,9000,0\r\n";
	char *cipsend = "AT+CIPSEND\r\n";


	//谁是4.2就变成了透传模式，或者说连上这个模块的机器就是服务器，0代表远端不变

	write(uart_fd, cipmode, strlen(cipmode));
	sleep(1);
	write(uart_fd, cipstart, strlen(cipstart));
	sleep(1);
	write(uart_fd, cipsend, strlen(cipsend));
	sleep(1);


}

void lcd_put_pixel(int x, int y, unsigned int color)
{
	unsigned char *pen_8 = fbp + y * line_width + x * pixel_width;
	unsigned short *pen_16;
	unsigned int *pen_32;
	unsigned char red, green, blue;

	pen_16 = (unsigned short *)pen_8;
	pen_32 = (unsigned int *)pen_8;

	switch (pixel_width * 8)
	{
	case 8:
		*pen_8 = color;
		break;

	case 16:
		/* 565 */
		red = (color >> 16) & 0xff;
		green = (color >> 8) & 0xff;
		blue = (color >> 0) & 0xff;
		color = ((red >> 3) << 11) | ((green >> 2) << 5) | ((blue >> 3));
		*pen_16 = color;
		break;

	case 32:
		*pen_32 = color;
		break;
	default:
		printf("can't support %ddpp\n", pixel_width * 8);
		break;
	}
}

void lcd_put_ascii(int x, int y, unsigned char c, unsigned int frontcolor, unsigned int backcolor)
{
	unsigned char *dots = (unsigned char *)&fontdata_8x16[c * 16];
	int i, b;
	unsigned char byte;

	for (i = 0; i < 16; i++)
	{
		byte = dots[i];
		for (b = 7; b >= 0; b--)
		{
			if (byte & (1 << b))
			{
				lcd_put_pixel(x + 7 - b, y + i, frontcolor);
			}
			else
			{
				lcd_put_pixel(x + 7 - b, y + i, backcolor);
			}
		}
	}
}

void show_char(int value, int num, char str0[], char str1[])
{
	int i;
	int front_color_0, front_color_1;
	int back_color = 0x000000;
	if (value == 0 && num == 0)
	{
		front_color_0 = 0xff0000;
	}
	else if (value == 1 && num == 0)
	{
		front_color_0 = 0x00ff00;
	}
	else if (value == 0 && num == 1)
	{
		front_color_1 = 0xff0000;
	}
	else
	{
		front_color_1 = 0x00ff00;
	}

	for (i = 0; i < strlen(str0); ++i)
	{
		lcd_put_ascii(vinfo.xres / 2 - 8 * 6 + i * 8, vinfo.yres / 2, str0[i], front_color_0, back_color);
	}
	for (i = 0; i < strlen(str1); ++i)
	{
		lcd_put_ascii(vinfo.xres / 2 + 8 * 6 + i * 8, vinfo.yres / 2, str1[i], front_color_1, back_color);
	}
}

int set_opt(int uart_fd, int nSpeed, int nBits, char nEvent, int nStop)
{
	struct termios newtio, oldtio;
	if (tcgetattr(uart_fd, &oldtio) != 0)
	{
		perror("SetupSerial 1");
		return -1;
	}
	bzero(&newtio, sizeof(newtio));
	newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	switch (nBits)
	{
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 8:
		newtio.c_cflag |= CS8;
		break;
	}

	switch (nEvent)
	{
	case 'O':
		newtio.c_cflag |= PARENB;
		newtio.c_cflag |= PARODD;
		newtio.c_iflag |= (INPCK | ISTRIP);
		break;
	case 'E':
		newtio.c_iflag |= (INPCK | ISTRIP);
		newtio.c_cflag |= PARENB;
		newtio.c_cflag &= ~PARODD;
		break;
	case 'N':
		newtio.c_cflag &= ~PARENB;
		break;
	}

	switch (nSpeed)
	{
	case 2400:
		cfsetispeed(&newtio, B2400);
		cfsetospeed(&newtio, B2400);
		break;
	case 4800:
		cfsetispeed(&newtio, B4800);
		cfsetospeed(&newtio, B4800);
		break;
	case 9600:
		cfsetispeed(&newtio, B9600);
		cfsetospeed(&newtio, B9600);
		break;
	case 115200:
		cfsetispeed(&newtio, B115200);
		cfsetospeed(&newtio, B115200);
		break;
	case 460800:
		cfsetispeed(&newtio, B460800);
		cfsetospeed(&newtio, B460800);
		break;
	default:
		cfsetispeed(&newtio, B9600);
		cfsetospeed(&newtio, B9600);
		break;
	}
	if (nStop == 1)
		newtio.c_cflag &= ~CSTOPB;
	else if (nStop == 2)
		newtio.c_cflag |= CSTOPB;
	newtio.c_cc[VTIME] = 0;
	newtio.c_cc[VMIN] = 0;
	tcflush(uart_fd, TCIFLUSH);
	if ((tcsetattr(uart_fd, TCSANOW, &newtio)) != 0)
	{
		perror("com set error\r\n");
		return -1;
	}

	// printf("set done!\n\r");
	return 0;
}
