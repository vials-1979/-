#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <linux/fb.h>
#include <termios.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include "jpeglib.h"
#include <jerror.h>
#include <sys/time.h>
#include <stdlib.h>
#include <sys/select.h>
#include <errno.h>
#include"show_font.h"
#include "pwm_music.h"
#include "gpio_drv.h"
#include "pwm_music.h"

#define BUZZER_ON 1
#define BUZZER_OFF 0

int set_opt(int, int, int, char, int);
//"/dev/ttySAC3"是con2，靠近耳机接口的串口
void config_wifi(int uart_fd);
void lcd_put_pixel(int x, int y, unsigned int color);

void control_buzzer(int buzzer_fd, int *buzzer_flag);
void LCD_color_control(int uart_fd, char buffer[]);
unsigned int string_to_hex(char buffer[]);
void show_color(unsigned int pixel_width, unsigned int pixel_height, unsigned int color, int style);
void convert_command(char command[]);
void lcd_put_ascii(int x, int y, unsigned char c, unsigned int frontcolor, unsigned int backcolor);
void show_char(char str[]);
void show_image(char *filename);
unsigned long RGB888toRGB32(unsigned char red, unsigned char green, unsigned char blue); //颜色模型转换
int buzzer_music(int fd, char *buffer);

struct jpeg_decompress_struct cinfo;
struct jpeg_error_mgr jerr;
struct fb_var_screeninfo vinfo;
struct fb_fix_screeninfo finfo;
long int screen_size_Bytes = 0;
unsigned int pixel_width, pixel_height;
unsigned int line_Bytes;
unsigned int per_pixel_Bytes;
char *fbp = 0;
char str1[]="LED1";
char str2[]="LED2";

int main()
{
	int uart_fd, nByte;
	int buzzer_flag = 1;
	int led0_flag = 0, led1_flag = 0;
	char *uart1 = "/dev/ttySAC1";
	char buffer[512];
	char *uart_out = "please input\r\n";
	memset(buffer, 0, sizeof(buffer));
	printf("Ready to Init Uart1!\r\n");

	int framebuffer_fd = open("/dev/fb0", O_RDWR);
	if (framebuffer_fd == -1)
	{
		printf("error:can not open framebuffer device.\n");
		return -1;
	}
	printf("the framebuffer device was opened successfully.\n");

	if (ioctl(framebuffer_fd, FBIOGET_VSCREENINFO, &vinfo))
	{
		printf("error reading variable information.\n");
		return -3;
	}

	if (ioctl(framebuffer_fd, FBIOGET_FSCREENINFO, &finfo))
	{
		printf("Error reading fixed information.\n");
		return -4;
	}
	printf("success to map framebuffer device to memory.\n");

	pixel_width = vinfo.xres;
	pixel_height = vinfo.yres;
	line_Bytes = pixel_width * vinfo.bits_per_pixel / 8;
	per_pixel_Bytes = vinfo.bits_per_pixel / 8;
	screen_size_Bytes = pixel_width * pixel_height * vinfo.bits_per_pixel / 8;

	fbp = (char *)mmap(0, screen_size_Bytes, PROT_READ | PROT_WRITE, MAP_SHARED, framebuffer_fd, 0);
	if ((int)fbp == -1)
	{
		printf("error:failed to map framebuffer device to memory.\n");
		return -4;
	}

	memset(fbp, 0, screen_size_Bytes);

	/*******/
	int led_fd = open("/dev/leds", O_RDWR);
	if (led_fd == -1)
		printf("open /dev/leds failed!\r\n");

	int buzzer_fd = open("/dev/buzzer_ctl", O_RDWR);
	if (buzzer_fd == -1)
		printf("open /dev/buzzer_ct1 failed!\r\n");

	if ((uart_fd = open(uart1, O_RDWR | O_NOCTTY)) == -1)
		printf("open %s is failed!\r\n", uart1);
	else
	{
		printf("open %s is successfully!\r\n", uart1);
		set_opt(uart_fd, 115200, 8, 'N', 1);

		// WIFI config
		config_wifi(uart_fd);

		while (1)
		{
			while ((nByte = read(uart_fd, buffer, 512)) > 0)
			{
				printf("cmd: %s\n", buffer);
				if (buffer[0] != 'C')
				{
					convert_command(buffer);
				}
				if (buffer[0] == 'C' && buffer[8] == '1')
				{
					ioctl(led_fd, 1, 0);
					led0_flag = 1;
					memset(fbp, 0, screen_size_Bytes);
					show_image("./light.jpg");
					show_char(str1);

					write(uart_fd, buffer, nByte);
				}
				if (buffer[0] == 'C' && buffer[8] == '2')
				{
					ioctl(led_fd, 0, 0);
					led0_flag = 0;
					memset(fbp, 0, screen_size_Bytes);
					show_image("./dark.jpg");
					show_char(str1);

					write(uart_fd, buffer, nByte);
				}
				if (buffer[0] == 'C' && buffer[8] == '3')
				{
					ioctl(led_fd, 1, 1);
					led1_flag = 1;
					memset(fbp, 0, screen_size_Bytes);
					show_image("./light.jpg");
					show_char(str2);

					write(uart_fd, buffer, nByte);
				}
				if (buffer[0] == 'C' && buffer[8] == '4')
				{
					ioctl(led_fd, 0, 1);
					led1_flag = 0;
					memset(fbp, 0, screen_size_Bytes);
					show_image("./dark.jpg");
					show_char(str2);

					write(uart_fd, buffer, nByte);
				}
				if (buffer[0] == 'C' && buffer[8] == '5') // buzzer
				{
					control_buzzer(buzzer_fd, &buzzer_flag);
					write(uart_fd, buffer, nByte);
				}
				if (buffer[0] == 'C' && buffer[1] == '6') // color
				{
					LCD_color_control(uart_fd, buffer);
				}
				if (buffer[0] == 'C' && buffer[8] == '7') // buzzer_music
				{
					buzzer_music(uart_fd, buffer);
				}
			}
		}
	}

	return 0;
}

void config_wifi(int uart_fd)
{
	char *cipmode = "AT+CIPMODE=1\r\n";
	char *cipstart = "AT+CIPSTART=\"UDP\",\"192.168.4.2\",9000,9000,0\r\n";
	char *cipsend = "AT+CIPSEND\r\n";

	write(uart_fd, cipmode, strlen(cipmode));
	sleep(1);
	write(uart_fd, cipstart, strlen(cipstart));
	sleep(1);
	write(uart_fd, cipsend, strlen(cipsend));
	sleep(1);
}

void lcd_put_pixel(int x, int y, unsigned int color)
{
	unsigned char *pen_8 = fbp + y * line_Bytes + x * per_pixel_Bytes;
	unsigned short *pen_16;
	unsigned int *pen_32;
	unsigned char red, green, blue;

	pen_16 = (unsigned short *)pen_8;
	pen_32 = (unsigned int *)pen_8;

	switch (per_pixel_Bytes * 8)
	{
	case 8:
		*pen_8 = color;
		break;

	case 16:
		/* 565 */
		red = (color >> 16) & 0xff;
		green = (color >> 8) & 0xff;
		blue = (color >> 0) & 0xff;
		color = ((red >> 3) << 11) | ((green >> 2) << 5) | ((blue >> 3));
		*pen_16 = color;
		break;

	case 32:
		*pen_32 = color;
		break;
	default:
		printf("can't support %ddpp\n", per_pixel_Bytes * 8);
		break;
	}
}

void control_buzzer(int buzzer_fd, int *buzzer_flag)
{
	if (*buzzer_flag == 1)
	{
		ioctl(buzzer_fd, BUZZER_ON, 1);
		*buzzer_flag = 0;
		printf("[buzzer]: %d\n", *buzzer_flag);
	}
	else
	{
		ioctl(buzzer_fd, BUZZER_OFF, 1);
		*buzzer_flag = 1;
		printf("[buzzer]: %d\n", *buzzer_flag);
	}
}

int set_opt(int uart_fd, int nSpeed, int nBits, char nEvent, int nStop)
{
	struct termios newtio, oldtio;
	if (tcgetattr(uart_fd, &oldtio) != 0)
	{
		perror("SetupSerial 1");
		return -1;
	}
	bzero(&newtio, sizeof(newtio));
	newtio.c_cflag |= CLOCAL | CREAD;
	newtio.c_cflag &= ~CSIZE;

	switch (nBits)
	{
	case 7:
		newtio.c_cflag |= CS7;
		break;
	case 8:
		newtio.c_cflag |= CS8;
		break;
	}

	switch (nEvent)
	{
	case 'O':
		newtio.c_cflag |= PARENB;
		newtio.c_cflag |= PARODD;
		newtio.c_iflag |= (INPCK | ISTRIP);
		break;
	case 'E':
		newtio.c_iflag |= (INPCK | ISTRIP);
		newtio.c_cflag |= PARENB;
		newtio.c_cflag &= ~PARODD;
		break;
	case 'N':
		newtio.c_cflag &= ~PARENB;
		break;
	}

	switch (nSpeed)
	{
	case 2400:
		cfsetispeed(&newtio, B2400);
		cfsetospeed(&newtio, B2400);
		break;
	case 4800:
		cfsetispeed(&newtio, B4800);
		cfsetospeed(&newtio, B4800);
		break;
	case 9600:
		cfsetispeed(&newtio, B9600);
		cfsetospeed(&newtio, B9600);
		break;
	case 115200:
		cfsetispeed(&newtio, B115200);
		cfsetospeed(&newtio, B115200);
		break;
	case 460800:
		cfsetispeed(&newtio, B460800);
		cfsetospeed(&newtio, B460800);
		break;
	default:
		cfsetispeed(&newtio, B9600);
		cfsetospeed(&newtio, B9600);
		break;
	}
	if (nStop == 1)
		newtio.c_cflag &= ~CSTOPB;
	else if (nStop == 2)
		newtio.c_cflag |= CSTOPB;
	newtio.c_cc[VTIME] = 0;
	newtio.c_cc[VMIN] = 0;
	tcflush(uart_fd, TCIFLUSH);
	if ((tcsetattr(uart_fd, TCSANOW, &newtio)) != 0)
	{
		perror("com set error\r\n");
		return -1;
	}

	// printf("set done!\n\r");
	return 0;
}

void LCD_color_control(int uart_fd, char buffer[])
{
	int nByte;
	char color_buffer[7];
	int flag = 1;
	int i;
	unsigned int color;
	int style = -1;

	if (buffer[2] == 'P' && buffer[3] == 'u' && buffer[4] == 'r' && buffer[5] == 'e')
	{
		style = 0;
	}
	else if (buffer[2] == 'G' && buffer[3] == 'r' && buffer[4] == 'a' && buffer[5] == 'd')
	{
		style = 1;
	}

	if (buffer[6] == '#')
	{
		for (i = 0; i < 7; ++i)
		{
			color_buffer[i] = buffer[i + 6];
		}
		color = string_to_hex(color_buffer);
		show_color(pixel_width, pixel_height, color, style);
	}
}

unsigned int string_to_hex(char buffer[])
{
	unsigned int high, low;
	unsigned int color = 0;
	int i;
	for (i = 1; i <= 5; i += 2)
	{
		if (buffer[i] >= '0' && buffer[i] <= '9')
		{
			high = buffer[i] - '0';
		}
		else
		{
			if (buffer[i] >= 'A' && buffer[i] <= 'F')
			{
				high = buffer[i] - 'A' + 10;
			}
			else if (buffer[i] >= 'a' && buffer[i] <= 'f')
			{
				high = buffer[i] - 'a' + 10;
			}
		}

		if (buffer[i + 1] >= '0' && buffer[i + 1] <= '9')
		{
			low = buffer[i + 1] - '0';
		}
		else
		{
			if (buffer[i] >= 'A' && buffer[i] <= 'F')
			{
				low = buffer[i + 1] - 'A' + 10;
			}
			else if (buffer[i] >= 'a' && buffer[i] <= 'f')
			{
				low = buffer[i + 1] - 'a' + 10;
			}
		}

		color |= (high & 0xf) << 4 | (low & 0xf);
		if (i < 5)
			color = color << 8;
	}
	printf("color=%d\n", color);
	return color;
}

void show_color(unsigned int pixel_width, unsigned int pixel_height, unsigned int color, int style)
{
	unsigned int i, j;
	unsigned int *p;
	unsigned int *fb_addr = (unsigned int *)fbp;

	memset(fbp, 0, screen_size_Bytes);

	if (style == 0)
	{
		for (i = 0; i < pixel_height; ++i)
		{
			for (j = 0; j < pixel_width; ++j)
				*(fb_addr + i * pixel_width + j) = color;
		}
	}
	else if (style == 1)
	{
		if ((color + pixel_height) > 0xffffff)
		{
			color -= color + pixel_height - 0xffffff;
		}

		fb_addr = fb_addr + pixel_height / 4 * pixel_width + pixel_width / 4;
		for (i = 0; i < pixel_height / 2; ++i)
		{
			for (j = 0; j < pixel_width / 2; ++j)
				*(fb_addr + i * pixel_width + j) = color + i;
		}
	}
}

void convert_command(char command[])
{
	int index = 0;
	char com1[10] = "Command01!";
	char com2[10] = "Command03!";
	if (command[1] == '1')
	{
		while (com1[index] != '\0')
		{
			command[index] = com1[index];
			index++;
		}
		index = 0;
	}
	if (command[1] == '2')
	{
		while (com2[index] != '\0')
		{
			command[index] = com2[index];
			index++;
		}
		index = 0;
	}
}

void show_image(char *filename)
{
	FILE *infp;
	unsigned char *buffer;

	// memset(fbp, 0, screensize);

	if ((infp = fopen(filename, "r")) == NULL)
	{
		printf("Error:open %s failed \n", filename);
		exit(0);
	}

	cinfo.err = jpeg_std_error(&jerr); //保存报错信息

	jpeg_create_decompress(&cinfo); //建立解压缩结构体cinfo

	jpeg_stdio_src(&cinfo, infp);	//指定解压缩文件
	jpeg_read_header(&cinfo, TRUE); //确认文件格式是否为jpeg

	jpeg_start_decompress(&cinfo); //解压

	if ((cinfo.output_width > vinfo.xres) || (cinfo.output_height > vinfo.yres)) //大小判断
	{
		printf("too large JPEG file,can not display\n");
		exit(-1);
	}

	buffer = (unsigned char *)malloc(cinfo.output_width * cinfo.output_components); //将分配缓冲区存放图片内容,按行分配的(提示是按照图片的hang)

	int y = 0;

	while (cinfo.output_scanline < cinfo.output_height) //从缓冲区中按行绘图
	{
		jpeg_read_scanlines(&cinfo, &buffer, 1);
		int x;

		if (vinfo.bits_per_pixel == 32)
		{

			unsigned long color32; // rgb
			unsigned long *dst;
			for (x = 0; x < cinfo.output_width; x++)
			{
				color32 = RGB888toRGB32(buffer[x * 3], buffer[x * 3 + 1], buffer[x * 3 + 2]);
				if ((x > vinfo.xres) || (y > vinfo.yres))
					exit(-1);

				dst = ((unsigned long *)fbp + y * vinfo.xres + x);

				*dst = color32;
			}
		}
		y++; // next scanline
	}

	jpeg_finish_decompress(&cinfo);	 //结束任务
	jpeg_destroy_decompress(&cinfo); //摧毁对象
	free(buffer);					 //释放空间
	fclose(infp);					 //关闭fd
}

unsigned long RGB888toRGB32(unsigned char red, unsigned char green, unsigned char blue) //颜色模型转换
{
	unsigned long B = blue;
	unsigned long G = (green << 8) & 0x0000FF00;
	unsigned long R = (red << 16) & 0x00FF0000;
	return (unsigned long)(R | G | B);
}

int buzzer_music(int fd, char *buffer)
{
	int num = 1;
	int i = 0;
	int beep_fd;
	int div;
	int pre = 255;
	beep_fd = open("/dev/gpik", O_RDWR | O_NONBLOCK);
	if (beep_fd == -1)
	{
		perror("open");
		exit(1);
	}
	else
	{
		printf("open /dev/gpik successfully");
	}
	ioctl(beep_fd, PWM_ON);
	ioctl(beep_fd, SET_PRE, &pre);
	printf("entry before");

	for (i = 0; i < sizeof(MumIsTheBestInTheWorld) / sizeof(Note); i++)
	{
		read(fd, buffer, 512);
		if (buffer[0] == 'C' && buffer[8] == '8') // buzzer_music
		{
			ioctl(beep_fd, SET_PRE, &div);
			close(beep_fd);
			return -1;
		}
		ioctl(beep_fd, LED_ON, &num);
		usleep(40000);
		ioctl(beep_fd, LED_OFF, &num);
		usleep(40000);
		if (++num == 5)
			num = 1;
		div = (PCLK / 256 / 4) / (MumIsTheBestInTheWorld[i].pitch);
		ioctl(beep_fd, SET_CNT, &div);
		usleep(MumIsTheBestInTheWorld[i].dimation * 50);
		ioctl(beep_fd, SET_PRE, &div);
		
	}
	ioctl(beep_fd, SET_PRE, &div);
	for (i = 0; i < sizeof(Twinkle_Twinkle) / sizeof(Note); i++)
	{
		read(fd, buffer, 512);
		if (buffer[0] == 'C' && buffer[8] == '8') // buzzer_music
		{
			ioctl(beep_fd, SET_PRE, &div);
			close(beep_fd);
			return -1;
		}
		ioctl(beep_fd, LED_ON, &num);
		usleep(40000);
		ioctl(beep_fd, LED_OFF, &num);
		usleep(40000);
		if (++num == 5)
			num = 1;
		div = (PCLK / 256 / 4) / (Twinkle_Twinkle[i].pitch);
		ioctl(beep_fd, SET_CNT, &div);
		usleep(Twinkle_Twinkle[i].dimation * 50);
		ioctl(beep_fd, SET_PRE, &div);

		
	}
	ioctl(beep_fd, SET_PRE, &div);
	close(beep_fd);
	return 0;
}

void show_char(char str[])
{
    int i;
    int front_color_0, front_color_1;
    int back_color = 0xFFffff;
    front_color_0 = 0x00ff00;
    
    for (i = 0; i < strlen(str); ++i)
        lcd_put_ascii(vinfo.xres / 2+64+i * 8, vinfo.yres / 2, str[i], front_color_0, back_color);
    
}


void lcd_put_ascii(int x, int y, unsigned char c, unsigned int frontcolor, unsigned int backcolor)
{
    unsigned char *dots = (unsigned char *)&fontdata_8x16[c * 16];
    int i, b;
    unsigned char byte;

    for (i = 0; i < 16; i++)
    {
        byte = dots[i];
        for (b = 7; b >= 0; b--)
        {
            if (byte & (1 << b))
            {
                lcd_put_pixel(x + 7 - b, y + i, frontcolor);
            }
            else
            {
                lcd_put_pixel(x + 7 - b, y + i, backcolor);
            }
        }
    }
}