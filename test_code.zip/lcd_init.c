#include <sys/mman.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <string.h>
#include <unistd.h>
#include <linux/fb.h>
#include <math.h>

#define RGB888_R 0x00ff0000
#define RGB888_G 0x0000ff00
#define RGB888_B 0x000000ff

static struct fb_var_screeninfo var;
static int screen_size;
static unsigned char *fb_based;
static unsigned int pixel_width;
static unsigned int line_width;

void lcd_put_pixel(int x, int y, unsigned int color888)
{
	unsigned char *pen_8 = fb_based + y * line_width + x * pixel_width;
	//行数加偏移得到像素的位置
	unsigned short *pen_16;
	unsigned int *pen_32;

	pen_16 = (unsigned short *)pen_8;
	pen_32 = (unsigned int *)pen_8;

	switch (var.bits_per_pixel)
	{
	case 8:
	{
		*pen_8 = color888;
		break;
	}
	case 16:
	{
		unsigned char R = (color888 & RGB888_R) >> 19;
		unsigned char G = (color888 & RGB888_G) >> 10;
		unsigned char B = (color888 & RGB888_B) >> 3;

		unsigned short color565 = (R << 11) + (G << 5) + (B << 0);

		*pen_16 = color565;
		break;
	}
	case 32:
	{
		*pen_32 = color888;
		break;
	}
	}
}

void lcd_4color()
{
	//左上红色
	for (int i = 0; i < var.yres / 2; i++)
	{
		for (int j = 0; j < var.xres / 2; j++)
			lcd_put_pixel(j, i, 0x00ff0000);
	}

	//左下蓝色
	for (int i = var.yres / 2; i < var.yres; i++)
	{
		for (int j = 0; j < var.xres / 2; j++)
			lcd_put_pixel(j, i, 0x000000ff);
	}

	//右上绿色
	for (int i = 0; i < var.yres / 2; i++)
	{
		for (int j = var.xres / 2; j < var.xres; j++)
			lcd_put_pixel(j, i, 0x0000ff00);
	}

	//右下白色
	for (int i = var.yres / 2; i < var.yres; i++)
	{
		for (int j = var.xres / 2; j < var.xres; j++)
			lcd_put_pixel(j, i, 0xffffffff);
	}
};

void Draw_Triangle();

int main()
{
	int fb_open = open("/dev/fb0", O_RDWR);
	if (fb_open < 0)
	{
		printf("can't open /dev/fb0\n");
		return -1;
	}

	if (ioctl(fb_open, FBIOGET_VSCREENINFO, &var))
	{
		printf("can't get var!\n");
		return -1;
	}

	pixel_width = var.bits_per_pixel / 8;			 //像素大小
	line_width = var.xres * pixel_width;			 //每行有多少字节
	screen_size = var.xres * var.yres * pixel_width; //整个屏幕有多少字节？

	printf("the pixel_width is %d\t\n", pixel_width);
	printf("this screen  width is %d\t\n", var.xres);
	printf("this screen  height is %d\t\n", var.yres);
	printf("this screen  bpp is %d\t\n", var.bits_per_pixel);

	fb_based = (unsigned char *)mmap(NULL, screen_size, PROT_READ | PROT_WRITE, MAP_SHARED, fb_open, 0);

	if (fb_based == (unsigned char *)-1)
	{
		printf("can't mmap!\n");
		return -1;
	}

	memset(fb_based, 0, screen_size); //初始化为黑色

	//初始化屏幕颜色为红色
	// for(int i=0;i<var.yres;i++){
	// 	for(int j=0;j<var.xres;j++)
	// 	 lcd_put_pixel (j,i,0x00ff0000);

	// }

	// lcd_4color();
	Draw_Triangle();

	/*
	我们的屏幕大小为 y=272 x=480

	中点：136，240
	根据公式y=kx;
	我们来算k=240/开平方（136的平方+240的平方）
	*/

	close(fb_open);

	return 0;
}

void Draw_Triangle()
{

	//随着y的增加，x会变大

	double k1 = 240.0 / 136;
	int t2 = var.yres;
	for (int i = 0; i < var.xres / 2; i++)
	{
		for (int j = i / k1; j < t2; j++)
		{
			lcd_put_pixel(i, j, 0x0000ffff);
		}
		t2 = var.yres - i / k1;
	}

	//右三角
	int t = 0;
	for (int i = var.xres - 1; i >= var.xres / 2; i--)
	{

		for (int j = 136 * i / 240; j >= t; j--) // y
		{

			lcd_put_pixel(i, j, 0x0000ff00);
		}
		t = var.yres - 136 * i / 240;
	}

	double k = 136.0 / 240;
	int t1 = var.xres;
	for (int i = 0; i < var.yres / 2; i++)
	{
		for (int j = i / k; j < t1; j++)
		{
			lcd_put_pixel(j, i, 0x00ff0000);
		}
		t1 = var.xres - i / k;
	}

	k = 136.0 / 240;
	t1 = 0;
	for (int i = var.yres - 1; i >= var.yres / 2; i--)
	{
		for (int j = i / k; j > t1; j--)
		{

			lcd_put_pixel(j, i, 0x000000ff);
		}
		t1 = var.xres - i / k;
	}
}