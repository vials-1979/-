#include <stdlib.h>
#include <sys/select.h>
#include <sys/time.h>
#include <jpeglib.h>
#include <jerror.h>

void show_image(char *filename);

struct jpeg_decompress_struct cinfo;
struct jpeg_error_mgr jerr;

unsigned long RGB888toRGB32(unsigned char red, unsigned char green, unsigned char blue) //颜色模型转换
{
    unsigned long B = blue;
    unsigned long G = (green << 8) & 0x0000FF00;
    unsigned long R = (red << 16) & 0x00FF0000;
    return (unsigned long)(R | G | B);
}


void show_image(char *filename)
{
    FILE *infp;
    unsigned char *buffer;

    // memset(fbp, 0, screensize);

    if ((infp = fopen(filename, "r")) == NULL)
    {
        printf("Error:open %s failed \n", filename);
        exit(0);
    }

    cinfo.err = jpeg_std_error(&jerr); //保存报错信息

    jpeg_create_decompress(&cinfo); //建立解压缩结构体cinfo

    jpeg_stdio_src(&cinfo, infp);   //指定解压缩文件
    jpeg_read_header(&cinfo, TRUE); //确认文件格式是否为jpeg

    jpeg_start_decompress(&cinfo); //解压

    if ((cinfo.output_width > vinfo.xres) || (cinfo.output_height > vinfo.yres)) //大小判断
    {
        printf("too large JPEG file,can not display\n");
        exit(-1);
    }

    buffer = (unsigned char *)malloc(cinfo.output_width * cinfo.output_components); //将分配缓冲区存放图片内容,按行分配的(提示是按照图片的hang)

    int y = 0;

    while (cinfo.output_scanline < cinfo.output_height) //从缓冲区中按行绘图
    {
        jpeg_read_scanlines(&cinfo, &buffer, 1);

        if (vinfo.bits_per_pixel == 32)
        {

            unsigned long color32; // rgb
            unsigned long *dst;
            for (int x = 0; x < cinfo.output_width; x++)
            {
                color32 = RGB888toRGB32(buffer[x * 3], buffer[x * 3 + 1], buffer[x * 3 + 2]);
                if ((x > vinfo.xres) || (y > vinfo.yres))
                    exit(-1);

                dst = ((unsigned long *)fbp + y * vinfo.xres + x);

                *dst = color32;
            }
        }
        y++; // next scanline
    }

    jpeg_finish_decompress(&cinfo);  //结束任务
    jpeg_destroy_decompress(&cinfo); //摧毁对象
    free(buffer);                    //释放空间
    fclose(infp);                    //关闭fd
}