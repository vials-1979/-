#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/fb.h>
#include <unistd.h>
#include <jpeglib.h>
#define FB_DEVICE_NAME "/dev/fb0"
    static int fd;
static struct fb_var_screeninfo fb_var;
static unsigned char *fb_mem;
static unsigned int screen_size;
static unsigned int line_bytesize;
static unsigned int ppx_bytesize;
int fb_device_init(void);
int fb_show_line(int line_start, int line_end, int line_num, unsigned char *color_data);
void dis_a_pixel(unsigned int x, unsigned int y, unsigned int color);
int main(int argc, char **argv)
{
    // 1、分配jpeg对象结构体空间、并初始化
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    FILE *jpgFile;
    int row_stride;
    unsigned char *buffer;
    if (argc != 2)
    {
        return -1;
    }
    // 1.初始化framebuffer设备
    if (fb_device_init())
    {
        return -1;
    }
    // 2. 将err错误结构体关联到jpeg对象结构体
    cinfo.err = jpeg_std_error(&jerr);
    // 3. 初始化cinfo结构体
    jpeg_create_decompress(&cinfo);
    if ((jpgFile = fopen(argv[1], "r")) == NULL)
    {
        return -1;
    }
    // 4.指定数据源
    jpeg_stdio_src(&cinfo, jpgFile);
    // 5.获取文件头信息

    jpeg_read_header(&cinfo, TRUE);
    /* 源信息 */
    printf("image_width = %d\n", cinfo.image_width);
    printf("image_height = %d\n", cinfo.image_height);
    printf("num_components = %d\n", cinfo.num_components);
    // num_components 颜色通道数
    //  1 ： 灰度图
    //  2 ： 灰度图加透明度
    //  3 ： 红绿蓝 RGB 三色图 24
    //  4 ： 红绿蓝加透明度 RGBA 图 32
    /* 可选图像缩放 scale_num/scale_denom */
    // 6.开始解压缩
    jpeg_start_decompress(&cinfo);
    /* 输出的图象的信息 */
    // printf()....
    // cinfo.output_width
    // cinfo.output_height
    // 7.读取每一行数据并显示
    //计算一行的数据长度
    row_stride = cinfo.output_width * cinfo.output_components;
    // 申请内存
    buffer = malloc(row_stride);
    // 循环调用jpeg_read_scanlines获得解压的每行数据
    while (cinfo.output_scanline < cinfo.output_height)
    {
        jpeg_read_scanlines(&cinfo, &buffer, 1);
        fb_show_line(0, cinfo.output_width, cinfo.output_scanline, buffer);
    }
    // 8.解压完毕
    jpeg_finish_decompress(&cinfo);
    // 9.释放资源和退出程序
    free(buffer);
    jpeg_destroy_decompress(&cinfo);
    return 0;
}


int fb_device_init(void)
{

memset(fb_mem, 0, screen_size); // clear screen
return 1;
}


int fb_show_line(int line_start, int line_end, int line_num, unsigned char
*color_data)
{
 for (line_start;line_start< cinfo.output_width; x++) {
                *(fbmem + y * fb_width * 4 + x * 4)     = (unsigned char) buffer[x * 3 + 2];
                *(fbmem + y * fb_width * 4 + x * 4 + 1) = (unsigned char) buffer[x * 3 + 1];
                *(fbmem + y * fb_width * 4 + x * 4 + 2) = (unsigned char) buffer[x * 3 + 0];
                *(fbmem + y * fb_width * 4 + x * 4 + 3) = (unsigned char) 0;
            }
}


void dis_a_pixel(unsigned int x, unsigned y, unsigned int color)
{ //根据传入的像素坐标点和颜色，处理一个像素
//1.计算像素点在映射内存中的位置
//2.根据屏幕属性转换颜色
//3.将转换后的颜色写入到像素点对应的内存地址位置
}
