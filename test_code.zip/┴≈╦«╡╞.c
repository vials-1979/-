#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>





#define LIGHT_OFF 0
#define LIGHT_ON 1
int main()
{

    int fd = open("/dev/leds", O_RDWR);
    if (-1 == fd)
        exit(-1);

    ioctl(fd, 0, 0);
    close(fd);


}